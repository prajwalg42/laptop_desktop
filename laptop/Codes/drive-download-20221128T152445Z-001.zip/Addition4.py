print("Application to demonstrate Industrial programming")

def main():
    no1 = 10
    no2 = 11
    Ans = no1 + no2

    print("Addition is : ",Ans)

if __name__ == "__main__":
    main()