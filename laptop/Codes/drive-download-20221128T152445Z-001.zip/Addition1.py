print("Application to demonstrate Industrial programming")

print("Addition is : ",10+11)