
def Display(No):
    Cnt = 0

    while(Cnt < No):
        print("Hello")
        Cnt = Cnt + 1
    
Display(4)