print("Jay Ganesh...")
