
def Display(No):
    while(No > 0):
        print(No)
        No = No - 1

Display(4)
