print("Demonstration of Dictonary")

# Data : Heterogeneous
# Ordered : Yes
# Indexed : No
# Mutable : Yes
# Duplicates : No

programming = {"C" : "Ritchie", "C++" : "Stroustrup", "Java" : "Gosling" , "Python" : "Rossum", "C":"Thompson"}
Batches = {"PPA" : 18000, "LB" : 16700, "Python" : 16500, "Angular" : 15000}

print("Data of Dictonary : ",Batches)
print("Data type is : ",type(Batches))
print("Length of dictonary : ",len(Batches))
print("Value of PPA is :",Batches["PPA"])

print(programming)
