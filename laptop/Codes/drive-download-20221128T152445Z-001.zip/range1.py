

for i in range(1,5):
    print(i)

for i in range(1,10,2):
    print(i)
