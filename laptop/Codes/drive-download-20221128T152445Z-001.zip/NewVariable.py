no = 11

print("Value of no : ",no)
print("Data type of no is : ",type(no))
print("ID of no is : ",id(no))

i = 11
print("Value of i : ",i)
print("Data type of i is : ",type(i))
print("ID of i is : ",id(i))
