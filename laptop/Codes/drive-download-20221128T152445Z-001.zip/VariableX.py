no = 11
print(no)
print(type(no))

no = 3.7 
print(no)
print(type(no))

no = "Hello"
print(no)
print(type(no))

no = True
print(no)
print(type(no))


no1, no2, no3 = 11,21,51
print(no1)
print(no2)
print(no3)
