print("Application to demonstrate Industrial programming")

def main():
    print("Enter first number : ")
    no1 = int(input())
    print("Enter second number : ")
    no2 = int(input())
    Ans = no1 + no2

    print("Addition is : ",Ans)

if __name__ == "__main__":
    main()