import sys

print(sys.getrecursionlimit())

sys.setrecursionlimit(3001)

print(sys.getrecursionlimit())
