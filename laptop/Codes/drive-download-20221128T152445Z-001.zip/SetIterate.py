
Data = {11,21,51,101}
print("_____________________________")

print("Output using for")
for no in Data:
    print(no, end = " ")
print("\n_____________________________")
